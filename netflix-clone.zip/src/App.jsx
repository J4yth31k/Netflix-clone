const App = () => {
  return (
    <div style={{ color: 'white', background: 'black', height: '100vh' }}>
      <h1>Netflix Clone Starter</h1>
    </div>
  )
}

export default App
